- buat database baru dengan nama crud.
- kemudian import file img_dropzon.sql nya
- selesai.

################################################
www.kang-cahya.com
By, Cahya Dyazin